import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class OmokClassicGame extends OmokGameBase {

    private TextField inputField;

    @Override
    public void start(Stage primaryStage) {
        this.player = OmokGameLauncher.player;
        canvas = new javafx.scene.canvas.Canvas(CANVAS_WIDTH, CANVAS_HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        initCanvasAndBoard(gc);

        chatArea = new TextArea();
        chatArea.setEditable(false);
        chatArea.setWrapText(true);
        chatArea.setPrefHeight(100);
        chatArea.setPrefWidth(260);
        chatArea.setLayoutX(5);
        chatArea.setLayoutY(80);

        inputField = new TextField();
        inputField.setPromptText("채팅 입력...");
        inputField.setPrefWidth(260);
        inputField.setLayoutX(5);
        inputField.setLayoutY(160);
        inputField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                String msg = inputField.getText().trim();
                sendMessage(msg);
                inputField.clear();
            }
        });

        Pane rightPanel = new Pane();
        rightPanel.setPrefSize(300, CANVAS_HEIGHT);
        rightPanel.getChildren().addAll(chatArea, inputField);

        HBox root = new HBox(20);
        root.getChildren().addAll(canvas, rightPanel);

        Scene scene = new Scene(root, CANVAS_WIDTH + 300, CANVAS_HEIGHT);
        primaryStage.setTitle("기본 오목 게임 - " + player.getUsername());
        primaryStage.setScene(scene);
        primaryStage.show();

        setupNetwork();

        canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> handleBoardClick(e, gc));

        // 서버 메시지 수신 쓰레드
        new Thread(() -> {
            try {
                String msg;
                while ((msg = in.readLine()) != null) {

                    if (msg.startsWith("COLOR|")) {
                        String colorStr = msg.substring(6);
                        myColor = colorStr.equals("BLACK") ? Color.BLACK : Color.WHITE;
                        opponentColor = (myColor == Color.BLACK) ? Color.WHITE : Color.BLACK;
                        Platform.runLater(() -> {
                            chatArea.appendText("[시스템] 당신은 " + colorStr + " 돌입니다.\n");
                            if (colorStr.equals("BLACK")) {
                                chatArea.appendText("[시스템] 흑돌이 먼저 두는 게임입니다. 당신이 선입니다.\n");
                            } else {
                                chatArea.appendText("[시스템] 상대가 먼저 두면 당신이 백돌로 이어서 두세요.\n");
                            }
                        });
                    }

                    else if (msg.startsWith("MOVE|")) {
                        String[] parts = msg.split("\\|");
                        int row = Integer.parseInt(parts[1]);
                        int col = Integer.parseInt(parts[2]);
                        String colorStr = parts[3];

                        Color stoneColor = colorStr.equals("BLACK") ? Color.BLACK : Color.WHITE;
                        Dol dol = new DolNormal(col, row, stoneColor);
                        board[row][col] = dol;

                        Platform.runLater(() -> drawBoard(canvas.getGraphicsContext2D()));
                    }

                    else if (msg.startsWith("TURN|")) {
                        String turnName = msg.substring(5);
                        isMyTurn = turnName.equals(player.getUsername());
                        Platform.runLater(() -> chatArea.appendText("[시스템] " + (isMyTurn ? "내 턴입니다." : "상대 턴입니다.") + "\n"));
                    }

                    else if (msg.startsWith("MSG|")) {
                        String content = msg.substring(4);
                        Platform.runLater(() -> chatArea.appendText(content + "\n"));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void handleBoardClick(MouseEvent e, GraphicsContext gc) {
        if (!isMyTurn || isGameOver) return;

        int offsetX = (CANVAS_WIDTH - BOARD_SIZE) / 2;
        int offsetY = (CANVAS_HEIGHT - BOARD_SIZE) / 2;
        int col = (int) Math.round((e.getX() - offsetX) / CELL_SIZE);
        int row = (int) Math.round((e.getY() - offsetY) / CELL_SIZE);

        if (!isInBounds(row, col) || board[row][col] != null) return;

        Dol dol = new DolNormal(col, row, myColor);
        board[row][col] = dol;

        drawBoard(gc);

        Rule rule = new Rule(board, SIZE, this);
        if (rule.SamSam(row, col)) {
            board[row][col] = null;
            showWarning("금수", "쌍삼 금수입니다. 다른 자리에 놓아주세요.");
            return;
        }

        if (rule.checkWin(row, col)) {
            isGameOver = true;
            showInfo("게임 종료", (myColor == Color.BLACK ? "흑돌" : "백돌") + " 승리!");
        }

        isMyTurn = false;
        out.println("MOVE|" + row + "|" + col + "|" + (myColor == Color.BLACK ? "BLACK" : "WHITE"));
    }
    public static void show(Player player) {
        Platform.runLater(() -> {
            OmokClassicGame game = new OmokClassicGame();
            game.player = player;
            Stage stage = new Stage();
            game.start(stage);
        });
    }
}
