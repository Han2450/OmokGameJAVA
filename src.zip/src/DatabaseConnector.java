import java.sql.*;

public class DatabaseConnector {
    // DB 연결 설정
    private static final String URL = "jdbc:mysql://localhost:3306/omok_game";
    private static final String USER = "root";
    private static final String PASSWORD = "rlacks-1129";
    private static Connection conn;

    // DB 연결 메서드
    public static Connection getConnection() {
        if (conn == null) {
            try {
                // MySQL JDBC 드라이버를 명시적으로 로드
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (ClassNotFoundException e) {
                System.out.println("MySQL JDBC 드라이버를 찾을 수 없습니다.");
                e.printStackTrace();
            } catch (SQLException e) {
                System.out.println("Database connection error: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return conn;
    }

    // 사용자 이름 중복 체크 메서드
    public static boolean isUsernameTaken(String username) {
        Connection connection = getConnection();
        if (connection == null) {
            System.out.println("데이터베이스 연결 실패");
            return false;
        }
        String query = "SELECT COUNT(*) FROM users WHERE username = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0; // 0보다 크면 이미 존재
            }
        } catch (SQLException e) {
            System.out.println("Error checking username availability: " + e.getMessage());
        }
        return false; // 예외가 발생하지 않으면 사용자가 없다는 뜻
    }

    // 사용자 정보 삽입 메서드
    public static boolean insertUser(String username, String password, String email, String nickname) {
        Connection connection = getConnection();
        if (connection == null) {
            System.out.println("데이터베이스 연결 실패");
            return false;
        }
        String query = "INSERT INTO users (username, password, email, nickname) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, email);
            ps.setString(4, nickname);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // 삽입된 행이 하나 이상이면 성공
        } catch (SQLException e) {
            System.out.println("Error inserting user: " + e.getMessage());
        }
        return false; // 삽입 실패
    }

    // 사용자 인증 (로그인 시)
    public static boolean validateUser(String username, String password) {
        Connection connection = getConnection();
        if (connection == null) {
            System.out.println("데이터베이스 연결 실패");
            return false;
        }
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            return rs.next(); // 결과가 있으면 로그인 성공
        } catch (SQLException e) {
            System.out.println("Error validating user: " + e.getMessage());
        }
        return false; // 예외가 발생하면 로그인 실패
    }
}
