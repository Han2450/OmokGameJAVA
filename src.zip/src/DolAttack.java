import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class DolAttack extends Dol {
    private final Color strokeColor;

    public DolAttack(int col, int row, Color strokeColor) {
        super(col, row);
        this.strokeColor = strokeColor;
    }

    @Override
    public void draw(GraphicsContext gc, int offsetX, int offsetY) {
        int x = offsetX + col * OmokGameBase.CELL_SIZE;
        int y = offsetY + row * OmokGameBase.CELL_SIZE;

        Color fillColor = strokeColor.equals(Color.BLACK) ? Color.BLACK : Color.WHITE;
        Color textColor = fillColor.equals(Color.BLACK) ? Color.WHITE : Color.BLACK;

        gc.setFill(fillColor);
        gc.fillOval(x - 12, y - 12, 24, 24);

        gc.setStroke(strokeColor);
        gc.strokeOval(x - 12, y - 12, 24, 24);

        gc.setFill(textColor);
        gc.setFont(javafx.scene.text.Font.font("Arial", 16));
        gc.fillText("A", x - 5, y + 6); // 중앙에 'A' 표시
    }

    @Override
    public boolean isAttackDol() {
        return true;
    }

    @Override
    public boolean isWinningStone() {
        return false;
    }

    public Color getStrokeColor() {
        return strokeColor;
    }
}
