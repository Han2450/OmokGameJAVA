// ✅ OmokItemGame.java 예시
import java.io.IOException;


import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.application.Platform;

public class OmokItemGame extends OmokGameBase {

    private Button generalDolButton;
    private Button attackDolButton;
    private TextField inputField;

    private boolean useGeneralDol = false;
    private boolean isPlacingAttackDol = false;
    private boolean attackDolPlaced = false;

    @Override
    public void start(Stage primaryStage) {
        this.player = OmokGameLauncher.player;
        canvas = new javafx.scene.canvas.Canvas(CANVAS_WIDTH, CANVAS_HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        initCanvasAndBoard(gc);

        generalDolButton = new Button("장군돌 두기");
        generalDolButton.setLayoutX(5);
        generalDolButton.setLayoutY(20);
        generalDolButton.setPrefWidth(120);
        generalDolButton.setOnAction(e -> {
            if (!isMyTurn) {
                showWarning("턴 대기", "내 턴이 아닙니다.");
                return;
            }
            useGeneralDol = true;
        });

        attackDolButton = new Button("공격돌 두기");
        attackDolButton.setLayoutX(140);
        attackDolButton.setLayoutY(20);
        attackDolButton.setPrefWidth(120);
        attackDolButton.setOnAction(e -> {
            if (!isMyTurn) {
                showWarning("턴 대기", "내 턴이 아닙니다.");
                return;
            }
            if (attackDolPlaced) {
                showWarning("공격돌 제한", "공격돌은 한 번만 둘 수 있습니다.");
                return;
            }
            isPlacingAttackDol = true;
        });

        chatArea = new TextArea();
        chatArea.setEditable(false);
        chatArea.setWrapText(true);
        chatArea.setPrefHeight(100);
        chatArea.setPrefWidth(260);
        chatArea.setLayoutX(5);
        chatArea.setLayoutY(80);

        inputField = new TextField();
        inputField.setPromptText("채팅 입력...");
        inputField.setPrefWidth(260);
        inputField.setLayoutX(5);
        inputField.setLayoutY(160);
        inputField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                String msg = inputField.getText().trim();
                sendMessage(msg);
                inputField.clear();
            }
        });

        Pane rightPanel = new Pane();
        rightPanel.setPrefSize(300, CANVAS_HEIGHT);
        rightPanel.getChildren().addAll(generalDolButton, attackDolButton, chatArea, inputField);

        HBox root = new HBox(20);
        root.getChildren().addAll(canvas, rightPanel);

        Scene scene = new Scene(root, CANVAS_WIDTH + 300, CANVAS_HEIGHT);
        primaryStage.setTitle("아이템전 오목 게임 - " + player.getUsername());
        primaryStage.setScene(scene);
        primaryStage.show();

        setupNetwork();

        canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> handleBoardClick(e, gc));

        new Thread(() -> {
            try {
                String msg;
                while ((msg = in.readLine()) != null) {

                    if (msg.startsWith("COLOR|")) {
                        String colorStr = msg.substring(6);
                        myColor = colorStr.equals("BLACK") ? Color.BLACK : Color.WHITE;
                        opponentColor = (myColor == Color.BLACK) ? Color.WHITE : Color.BLACK;
                        Platform.runLater(() -> chatArea.appendText("[시스템] 당신은 " + colorStr + " 돌입니다.\n"));
                    }

                    else if (msg.startsWith("MOVE|")) {
                        String[] parts = msg.split("\\|");
                        int row = Integer.parseInt(parts[1]);
                        int col = Integer.parseInt(parts[2]);
                        String colorStr = parts[3];
                        String type = (parts.length > 4) ? parts[4] : "NORMAL";

                        Color stoneColor = colorStr.equals("BLACK") ? Color.BLACK : Color.WHITE;
                        Dol newDol;
                        switch (type) {
                            case "ATTACK": newDol = new DolAttack(col, row, stoneColor); break;
                            case "GENERAL": newDol = new DolGeneral(col, row, stoneColor); break;
                            default: newDol = new DolNormal(col, row, stoneColor);
                        }
                        board[row][col] = newDol;
                        Platform.runLater(() -> drawBoard(canvas.getGraphicsContext2D()));
                    }

                    else if (msg.startsWith("TURN|")) {
                        String turnName = msg.substring(5);
                        isMyTurn = turnName.equals(player.getUsername());
                        Platform.runLater(() -> chatArea.appendText("[시스템] " + (isMyTurn ? "내 턴입니다." : "상대 턴입니다.") + "\n"));
                    }

                    else if (msg.startsWith("MSG|")) {
                        String content = msg.substring(4);
                        Platform.runLater(() -> chatArea.appendText(content + "\n"));
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void handleBoardClick(MouseEvent e, GraphicsContext gc) {
        if (isGameOver || !isMyTurn) return;

        int offsetX = (CANVAS_WIDTH - BOARD_SIZE) / 2;
        int offsetY = (CANVAS_HEIGHT - BOARD_SIZE) / 2;
        int col = (int) Math.round((e.getX() - offsetX) / CELL_SIZE);
        int row = (int) Math.round((e.getY() - offsetY) / CELL_SIZE);

        if (!isInBounds(row, col) || board[row][col] != null) return;

        Dol placed;
        if (isPlacingAttackDol) {
            placed = new DolAttack(col, row, myColor);
            isPlacingAttackDol = false;
            attackDolPlaced = true;
        } else if (useGeneralDol) {
            placed = new DolGeneral(col, row, myColor);
            useGeneralDol = false;
        } else {
            placed = new DolNormal(col, row, myColor);
        }

        board[row][col] = placed;
        drawBoard(gc);

        Rule rule = new Rule(board, SIZE, this);
        if (rule.SamSam(row, col)) {
            board[row][col] = null;
            showWarning("금수", "쌍삼 금수입니다. 다른 자리에 놓아주세요.");
            return;
        }

        if (rule.checkWin(row, col)) {
            isGameOver = true;
            showInfo("게임 종료", (myColor == Color.BLACK ? "흑돌" : "백돌") + " 승리!");
        }

        isMyTurn = false;
        String type = placed instanceof DolAttack ? "ATTACK" : placed instanceof DolGeneral ? "GENERAL" : "NORMAL";
        out.println("MOVE|" + row + "|" + col + "|" + (myColor == Color.BLACK ? "BLACK" : "WHITE") + "|" + type);
    }
    public static void show(Player player) {
        Platform.runLater(() -> {
            OmokItemGame game = new OmokItemGame();
            game.player = player;
            Stage stage = new Stage();
            game.start(stage);
        });
    }
}
