// ✅ OmokGameBase.java
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.paint.Color;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public abstract class OmokGameBase extends Application {

    protected static final int SIZE = 19;
    protected static final int CELL_SIZE = 30;
    protected static final int BOARD_SIZE = (SIZE - 1) * CELL_SIZE;
    protected static final int PADDING = 20;
    protected static final int CANVAS_WIDTH = BOARD_SIZE + PADDING * 2;
    protected static final int CANVAS_HEIGHT = BOARD_SIZE + PADDING * 2;

    protected Dol[][] board = new Dol[SIZE][SIZE];
    protected Canvas canvas;
    protected Player player;

    protected boolean isMyTurn = true;
    protected boolean isGameOver = false;

    protected Color myColor = Color.BLACK;
    protected Color opponentColor = Color.WHITE;

    protected Socket socket;
    protected BufferedReader in;
    protected PrintWriter out;

    protected TextArea chatArea;

    public void setPlayer(Player player) {
        this.player = player;
    }

    protected void setupNetwork() {
        try {
            socket = new Socket("0.tcp.jp.ngrok.io", 11179);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            out.println("HELLO|" + player.getUsername());

            Platform.runLater(() -> {
                chatArea.appendText("[시스템] 서버에 연결되었습니다.\n");
                showInfo("연결 성공", "서버에 성공적으로 연결되었습니다.");
            });

        } catch (Exception e) {
            Platform.runLater(() -> showError("서버 연결 실패", "서버에 연결할 수 없습니다.\n인터넷 또는 주소를 확인하세요."));
            e.printStackTrace();
        }
    }

    protected void sendMessage(String msg) {
        if (!msg.isEmpty() && out != null) {
            out.println("MSG|" + player.getUsername() + "  | " + msg);
        }
    }

    protected void drawBoard(GraphicsContext gc) {
        gc.setFill(Color.rgb(238, 207, 161));
        gc.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

        int offsetX = (CANVAS_WIDTH - BOARD_SIZE) / 2;
        int offsetY = (CANVAS_HEIGHT - BOARD_SIZE) / 2;

        gc.setStroke(Color.BLACK);
        for (int i = 0; i < SIZE; i++) {
            gc.strokeLine(offsetX + i * CELL_SIZE, offsetY, offsetX + i * CELL_SIZE, offsetY + BOARD_SIZE);
            gc.strokeLine(offsetX, offsetY + i * CELL_SIZE, offsetX + BOARD_SIZE, offsetY + i * CELL_SIZE);
        }

        int[] points = {3, 9, 15};
        gc.setFill(Color.BLACK);
        for (int row : points) {
            for (int col : points) {
                gc.fillOval(offsetX + col * CELL_SIZE - 4, offsetY + row * CELL_SIZE - 4, 8, 8);
            }
        }

        for (int row = 0; row < SIZE; row++) {
            for (int col = 0; col < SIZE; col++) {
                if (board[row][col] != null) {
                    board[row][col].draw(gc, offsetX, offsetY);
                }
            }
        }
    }

    protected void initCanvasAndBoard(GraphicsContext gc) {
        drawBoard(gc); // 공통 초기 보드 표시
    }

    protected boolean isInBounds(int row, int col) {
        return row >= 0 && row < SIZE && col >= 0 && col < SIZE;
    }

    protected void showWarning(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    protected void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    protected void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @Override
    public abstract void start(javafx.stage.Stage primaryStage);
}
