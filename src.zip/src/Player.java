public class Player {
    private String username;
    private final boolean isBlack;

    
    public Player(String username, boolean isBlack) {
        this.username = username;
        this.isBlack = isBlack;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isBlack() {
        return isBlack;
    }

    @Override
    public String toString() {
        return username + " (" + (isBlack ? "흑돌" : "백돌") + ")";
    }
}
