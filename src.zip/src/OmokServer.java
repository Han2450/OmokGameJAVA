import java.io.*;
import java.net.*;
import java.util.*;

public class OmokServer {

    private ServerSocket serverSocket;
    private List<ClientHandler> clients = Collections.synchronizedList(new ArrayList<>());

    private String currentTurn = "BLACK"; // 턴 관리 - 흑돌부터 시작
    private String[][] board = new String[19][19]; // 보드 상태 (BLACK, WHITE, null)

    public OmokServer(int port) throws IOException {
        serverSocket = new ServerSocket(port);
        System.out.println("서버 시작 - 포트 " + port);

        // 초기 보드 상태 초기화
        resetBoard();

        // 클라이언트 연결 대기
        while (true) {
            Socket clientSocket = serverSocket.accept();
            if (clients.size() >= 5) {
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                out.println("MSG|서버|현재 게임에 참여할 수 없습니다.");
                clientSocket.close();
                continue;
            }
            ClientHandler clientHandler = new ClientHandler(clientSocket);
            clients.add(clientHandler);
            clientHandler.start();
        }
    }

    // 보드/턴 초기화
    private synchronized void resetBoard() {
        for (int i = 0; i < 19; i++)
            Arrays.fill(board[i], null);
        currentTurn = "BLACK";
    }

    // 게임 상태(보드, 클라이언트) 전체 초기화 + 클라이언트 소켓 닫기
    private synchronized void resetGame() {
        System.out.println("게임이 초기화됩니다.");

        // 모든 클라이언트에게 게임 종료 메시지 발송 및 소켓 닫기
        synchronized (clients) {
            for (ClientHandler client : clients) {
                client.sendMessage("MSG|서버|게임이 종료되었습니다.");
                try {
                    client.socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            clients.clear();
        }
        // 보드/턴 초기화
        resetBoard();
    }

    // 새 플레이어 접속 시 색깔 할당
    private synchronized String assignColor() {
        if (clients.size() == 0) return "BLACK";
        else if (clients.size() == 1) return "WHITE";
        else return "SPECTATOR";
    }

    // 모든 클라이언트에 메시지 보내기
    private void broadcast(String message) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                client.sendMessage(message);
            }
        }
    }

    // 턴 변경 메시지 브로드캐스트
    private void broadcastTurn() {
        String currentPlayer = currentTurn.equals("BLACK") ? getPlayerName("BLACK") : getPlayerName("WHITE");
        broadcast("TURN|" + currentPlayer);
    }

    // 플레이어 이름 찾기 (ClientHandler 내에 playerName 저장 필요)
    private String getPlayerName(String color) {
        synchronized (clients) {
            for (ClientHandler c : clients) {
                if (color.equals(c.color)) {
                    return c.playerName;
                }
            }
        }
        return "";
    }

    // 돌 놓기 요청 처리
    private synchronized boolean placeStone(String playerColor, int row, int col, String type) {
        if (!playerColor.equals(currentTurn)) {
            return false;
        }
        if (row < 0 || row >= 19 || col < 0 || col >= 19) {
            return false;
        }
        if (board[row][col] != null) {
            return false;
        }

        // 돌 종류 포함해서 보드에 저장 ("BLACK_ATTACK", "WHITE_GENERAL" 등)
        board[row][col] = playerColor + "_" + type;

        // 돌 종류 포함해서 클라이언트들에게 전송
        broadcast("MOVE|" + row + "|" + col + "|" + playerColor + "|" + type);

        // 턴 교대
        currentTurn = currentTurn.equals("BLACK") ? "WHITE" : "BLACK";
        broadcastTurn();

        return true;
    }

    // 서버/클라이언트 전체 종료 (Ctrl+C 등에서 호출)
    public void shutdown() {
        try {
            System.out.println("서버 종료 중...");
            synchronized (clients) {
                for (ClientHandler client : clients) {
                    try {
                        client.socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                clients.clear();
            }
            if (serverSocket != null && !serverSocket.isClosed())
                serverSocket.close();
            System.out.println("서버가 종료되었습니다.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    class ClientHandler extends Thread {
        private Socket socket;
        private BufferedReader in;
        private PrintWriter out;
        private String playerName = "";
        private String color;

        public ClientHandler(Socket socket) {
            this.socket = socket;
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                this.color = assignColor();
                out.println("COLOR|" + color);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void sendMessage(String msg) {
            out.println(msg);
        }

        @Override
        public void run() {
            try {
                // 닉네임 받기 (첫 메시지로 가정)
                playerName = in.readLine();
                broadcast("NICK|" + playerName);

                // 첫 접속자에게 턴 알림 (흑돌이 먼저 시작)
                if (color.equals("BLACK")) {
                    broadcastTurn();
                }

                String msg;
                while ((msg = in.readLine()) != null) {
                    if (msg.startsWith("MOVE|")) {
                        String[] parts = msg.split("\\|");
                        int row = Integer.parseInt(parts[1]);
                        int col = Integer.parseInt(parts[2]);
                        String type = parts.length > 4 ? parts[4] : "NORMAL";

                        boolean success = placeStone(color, row, col, type);
                        if (!success) {
                            sendMessage("MSG|서버|잘못된 움직임입니다.");
                        }
                    } else if (msg.startsWith("MSG|")) {
                        broadcast(msg);
                    } else if (msg.equals("EXIT")) {
                        // 플레이어가 "EXIT" 전송하면 게임 종료 처리
                        System.out.println(playerName + " 님이 게임 종료를 요청함.");
                        resetGame();
                        break;
                    }
                }
            } catch (IOException e) {
                System.out.println(playerName + " 연결 종료: " + e.getMessage());
            } finally {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                clients.remove(this);
                System.out.println(playerName + " 님이 나갔습니다.");
            }
        }
    }

    // 서버 실행 메인
    public static void main(String[] args) {
        OmokServer server = null;
        try {
            server = new OmokServer(10734);
        } catch (IOException e) {
            e.printStackTrace();
        }
        OmokServer finalServer = server;
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (finalServer != null) {
                finalServer.shutdown();
            }
        }));
    }
}
