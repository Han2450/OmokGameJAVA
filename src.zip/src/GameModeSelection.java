import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class GameModeSelection {

    public static void show(Player player) {
        Stage stage = new Stage();

        Label label = new Label("게임 모드를 선택하세요:");
        Button classicBtn = new Button("클래식 오목 게임");
        Button itemBtn = new Button("아이템 오목 게임");

        VBox vbox = new VBox(15, label, classicBtn, itemBtn);
        vbox.setPadding(new Insets(20));
        Scene scene = new Scene(vbox, 300, 180);

        stage.setTitle("게임 모드 선택");
        stage.setScene(scene);
        stage.show();

        classicBtn.setOnAction(e -> {
            stage.close();
            OmokClassicGame.show(player);
        });
        
        itemBtn.setOnAction(e -> {
            stage.close();
            OmokItemGame.show(player);
        });
    }
}
