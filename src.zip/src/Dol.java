import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// 🔷 돌 추상 클래스
abstract class Dol {
    protected int col;
    protected int row;

    public Dol(int col, int row) {
        this.col = col;
        this.row = row;
    }

    public Dol() {
        this.col = -1;
        this.row = -1;
    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }

    public boolean isAttackDol() {
        return false;
    }

    public boolean isGeneralDol() {
        return false;
    }

    public boolean isWinningStone() {
        return true;
    }

    public abstract void draw(GraphicsContext gc, int offsetX, int offsetY);
}


// ⚫️ 흑돌 클래스
class BlackDol extends Dol {
    public BlackDol() {
        super();
    }

    public BlackDol(int col, int row) {
        super(col, row);
    }

    @Override
    public void draw(GraphicsContext gc, int offsetX, int offsetY) {
        gc.setFill(Color.BLACK);
        gc.fillOval(offsetX + col * 30 - 10,
                    offsetY + row * 30 - 10,
                    20, 20);
    }
}

// ⚪️ 백돌 클래스
class WhiteDol extends Dol {
    public WhiteDol() {
        super();
    }

    public WhiteDol(int col, int row) {
        super(col, row);
    }

    @Override
    public void draw(GraphicsContext gc, int offsetX, int offsetY) {
        gc.setFill(Color.WHITE);
        gc.fillOval(offsetX + col * 30 - 10,
                    offsetY + row * 30 - 10,
                    20, 20);
        gc.setStroke(Color.BLACK);
        gc.strokeOval(offsetX + col * 30 - 10,
                      offsetY + row * 30 - 10,
                      20, 20);
    }
}
