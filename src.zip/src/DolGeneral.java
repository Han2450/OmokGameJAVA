import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class DolGeneral extends Dol {
    private final Color strokeColor;

    public DolGeneral(int col, int row, Color strokeColor) {
        super(col, row);
        this.strokeColor = strokeColor;
    }

    @Override
    public void draw(GraphicsContext gc, int offsetX, int offsetY) {
        int x = offsetX + col * OmokGameBase.CELL_SIZE;
        int y = offsetY + row * OmokGameBase.CELL_SIZE;

        Color fillColor = strokeColor.equals(Color.BLACK) ? Color.BLACK : Color.WHITE;
        Color outlineColor = Color.GOLD;

        gc.setFill(fillColor);
        gc.fillOval(x - 12, y - 12, 24, 24);

        gc.setStroke(outlineColor);
        gc.setLineWidth(3);
        gc.strokeOval(x - 12, y - 12, 24, 24);

        gc.setLineWidth(1); // 다시 원상복구
    }

    @Override
    public boolean isAttackDol() {
        return false;
    }

    @Override
    public boolean isWinningStone() {
        return true; // 장군돌은 승리 조건에 포함됨
    }

    public Color getStrokeColor() {
        return strokeColor;
    }
}
