import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class DolNormal extends Dol {
    private final Color color;

    public DolNormal(int col, int row, Color color) {
        super(col, row);
        this.color = color;
    }

    @Override
    public void draw(GraphicsContext gc, int offsetX, int offsetY) {
        gc.setFill(color);
        gc.fillOval(offsetX + col * 30 - 10,
                    offsetY + row * 30 - 10,
                    20, 20);

        if (color.equals(Color.WHITE)) {
            gc.setStroke(Color.BLACK);
            gc.strokeOval(offsetX + col * 30 - 10,
                          offsetY + row * 30 - 10,
                          20, 20);
        }
    }
}
