import javafx.application.Application;
import javafx.stage.Stage;

public class OmokGameLauncher extends Application {

    public static Player player;
    public static boolean itemMode;

    @Override
    public void start(Stage primaryStage) {
        // 게임이 시작될 때 첫 번째 화면으로 AuthScreen을 띄우도록 수정
        AuthScreen.show(primaryStage);
    }

    public static void launchGame(Player p, boolean isItemMode) {
        player = p;
        itemMode = isItemMode;

        // 아이템 모드와 클래식 모드에 맞게 게임 시작
        if (itemMode) {
            Application.launch(OmokItemGame.class);
        } else {
            Application.launch(OmokClassicGame.class);
        }
    }

    public static void main(String[] args) {
        launch(args);  // main 메서드에서 launch()만 호출
    }
}
