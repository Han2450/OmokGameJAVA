import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class AuthScreen {
    public static void show(Stage primaryStage) {
        // 로그인 화면 UI 구성
        Label idLabel = new Label("아이디 ");
        TextField idField = new TextField();

        Label pwLabel = new Label("비밀번호 ");
        PasswordField pwField = new PasswordField();

        Button loginButton = new Button("로그인");
        Button signupButton = new Button("회원가입");

        Label messageLabel = new Label();

        // 로그인 화면
        VBox vbox = new VBox(10, idLabel, idField, pwLabel, pwField, loginButton, signupButton, messageLabel);
        vbox.setPadding(new Insets(20));

        Scene loginScene = new Scene(vbox, 300, 250);
        primaryStage.setTitle("로그인");
        primaryStage.setScene(loginScene);
        primaryStage.show();

        // 로그인 버튼 눌렀을 때
        loginButton.setOnAction(e -> {
            String id = idField.getText();
            String pw = pwField.getText();

            if (id.isEmpty() || pw.isEmpty()) {
                messageLabel.setText("아이디와 비밀번호를 입력하세요.");
            } else if (DatabaseConnector.validateUser(id, pw)) {
                Player player = new Player(id, true); // 로그인 성공
                player.setUsername(id);
                OmokGameLauncher.player = player;
                GameModeSelection.show(player); // 로그인 후 게임 모드 선택 화면으로 이동
                primaryStage.close();
            } else {
                messageLabel.setText("아이디 또는 비밀번호가 잘못되었습니다.");
            }
        });
        

        // 회원가입 버튼 눌렀을 때
        signupButton.setOnAction(e -> {
            // 로그인 화면 숨기고 회원가입 화면 표시
            idLabel.setVisible(false);
            idField.setVisible(false);
            pwLabel.setVisible(false);
            pwField.setVisible(false);
            loginButton.setVisible(false);
            signupButton.setVisible(false);

            // 회원가입 화면 UI 구성
            Label nicknameLabel = new Label("닉네임 ");
            TextField nicknameField = new TextField();
            Label SignUpIdLabel = new Label("아이디 ");
            TextField SignUpIdField = new TextField();
            Label SignUpPwLabel = new Label("비밀번호 ");
            TextField SignUpPwField = new TextField();
            Label SignUpEmailLabel = new Label("이메일 ");
            TextField SignUpEmailField = new TextField();
            Button backButton = new Button("뒤로 가기");
            Button registerButton = new Button("회원가입");
            Label signupMessageLabel = new Label();

            // 회원가입 화면 표시
            VBox signupVBox = new VBox(10, SignUpIdLabel, SignUpIdField, SignUpPwLabel, SignUpPwField, SignUpEmailLabel, SignUpEmailField, nicknameLabel, nicknameField, registerButton, signupMessageLabel, backButton);
            signupVBox.setPadding(new Insets(20));

            primaryStage.setScene(new Scene(signupVBox, 300, 400));

            // 회원가입 처리
            registerButton.setOnAction(event -> {
                String idForSignUp = SignUpIdField.getText();
                String passwordForSignUp = SignUpPwField.getText();
                String emailForSignUp = SignUpEmailField.getText();
                String nickname = nicknameField.getText();

                if (idForSignUp.isEmpty() || passwordForSignUp.isEmpty() || emailForSignUp.isEmpty() || nickname.isEmpty()) {
                    signupMessageLabel.setText("모든 필드를 채워주세요.");
                } else if (DatabaseConnector.isUsernameTaken(idForSignUp)) {
                    signupMessageLabel.setText("이미 사용 중인 아이디입니다.");
                } else {
                    if (DatabaseConnector.insertUser(idForSignUp, passwordForSignUp, emailForSignUp, nickname)) {
                        signupMessageLabel.setText("회원가입 성공!");
                        // 회원가입 후 로그인 화면으로 돌아가기
                        idLabel.setVisible(true);
                        idField.setVisible(true);
                        pwLabel.setVisible(true);
                        pwField.setVisible(true);
                        loginButton.setVisible(true);
                        signupButton.setVisible(true);

                        primaryStage.setScene(loginScene); // 로그인 화면으로 돌아감
                    } else {
                        signupMessageLabel.setText("회원가입에 실패했습니다.");
                    }
                }
            });

            // 뒤로 가기 버튼 눌렀을 때
            backButton.setOnAction(event -> {
                // 회원가입 화면 숨기고 로그인 화면으로 돌아가기
                idLabel.setVisible(true);
                idField.setVisible(true);
                pwLabel.setVisible(true);
                pwField.setVisible(true);
                loginButton.setVisible(true);
                signupButton.setVisible(true);

                primaryStage.setScene(loginScene); // 로그인 화면으로 돌아감
            });
        });
    }
}